echo hello
 sleep 5
echo program is installer!!!
 sleep 5
echo program  nmap,metasploitframefork,fluxion,wifite!!

