
echo "admin tools"

echo "update and upgrade"
sleep 4
apt update        # update
apt upgrade -y    # upgrade


echo "wireshark"
sleep 4
apt install wireshark -y  # install wireshark


echo "nmap"
sleep 4
apt install nmap -y        # install nmap


echo "git"
sleep 4
apt install git -y         # install git


echo "metasploit-framework"
sleep 4
git clone https://raw.githubusercontent.com/rapid7/metasploit-omnibus/master/config/templates/metasploit-framework-wrappers/msfupdate.erb > msfinstall && \
chmod 755 msfinstall && \
./msfinstall
# installing metasploit-framework


echo "wifite"
sleep 4
apt install  wifite
apt-get install  pkg-config libnl-3-dev libnl-genl-3-dev libpcap-dev
# installing wifite


echo "mdk4"
sleep 4
git clone https://github.com/aircrack-ng/mdk4
cd mdk4
make
sudo make install
cd $HOME
# installing mdk4


echo "aircrack-ng"
sleep 4
sudo apt-get install  \
    build-essential autoconf automake libtool pkg-config \
    libnl-3-dev libnl-genl-3-dev libssl-dev ethtool shtool rfkill \
    zlib1g-dev libpcap-dev libsqlite3-dev libpcre2-dev libhwloc-dev \
    libcmocka-dev hostapd wpasupplicant tcpdump screen iw usbutils expect
# installing aircrack-ng


echo "python"
sleep 4
apt install  python         # python


echo "goldeneye"
sleep 4
apt install  goldeneye      # goldeneye ddos


echo "siege"
sleep 4
apt install  siege          # siege ddos  (typo fixed: insall → install)


echo "c++"
sleep 4
apt install  g++            # c++


echo "wine"
sleep 4
apt install  wine           # windows emulator


echo "vncserver"
sleep 4
apt install  tigervncserver
apt install  tigervncpasswd
tigervncpasswd                # vncserver


echo "htop"
sleep 4
apt install  htop           # install htop


echo "virtualbox"
sleep 4
apt install  virtualbox     # install virtualbox


echo "neofetch"
sleep 4
apt install  neofetch       # install neofetch


echo "fluxion"
sleep 4
git clone https://github.com/FluxionNetwork/fluxion
cd fluxion
./fluxion.sh i
cd $HOME
# installing fluxion


echo "bb"
sleep 4
apt install  bb             # install bb


echo "wifite2"
sleep 4
git clone https://github.com/derv82/wifite2.git
cd wifite2
cd $HOME
# installing wifite2


echo "arduino"
sleep 4
apt install  arduino        # install arduino


echo "wifiphisher"
sleep 4
git clone https://github.com/wifiphisher/wifiphisher.git
cd wifiphisher
cd $HOME
# installing wifiphisher


neofetch
sleep 5
sh 2.sh
